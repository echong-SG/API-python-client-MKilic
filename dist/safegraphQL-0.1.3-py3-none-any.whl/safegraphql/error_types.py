class safeGraphError(Exception):
	pass