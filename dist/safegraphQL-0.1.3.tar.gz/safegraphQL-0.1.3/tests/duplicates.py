import pandas as pd

path = "duplicate_tokens2.csv"
df = pd.read_csv(path)
import pdb;pdb.set_trace()